package Gateways;

public interface Gateway {
 
	public void sendMessage(Object message, String user);
}
