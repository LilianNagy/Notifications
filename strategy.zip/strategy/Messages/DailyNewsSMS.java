package Messages;

public  class DailyNewsSMS implements DailyNews{

	@Override
	public String prepareMessage(String[] placeHolders) {
		return "Daily News SMS";
	}

	

	

	

}
