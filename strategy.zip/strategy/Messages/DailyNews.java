package Messages;



public interface DailyNews {
	
	public  String prepareMessage(String[] placeHolders); 
	
		
	}

