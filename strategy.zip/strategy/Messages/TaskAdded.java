package Messages;

public interface TaskAdded {

	public String prepareMessage(String[] placeHolders);
	
	public void addTeamDescription();
}
